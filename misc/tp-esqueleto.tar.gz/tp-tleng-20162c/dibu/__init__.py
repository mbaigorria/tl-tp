"""Entrypoint de Dibu"""

from .parser import parse