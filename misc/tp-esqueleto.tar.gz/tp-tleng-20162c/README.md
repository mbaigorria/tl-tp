# TP Teoría de Lenguajes 2016, Segundo Cuatrimestre

# Dibu


# Instrucciones de uso

1. Instalar requerimientos

```
$ pip install -r requirements.txt
```

2. Correr `Jupyter`

```
$ jupyter notebook
```

En `notebooks/dibu.ipynb` tienen ejemplos y cómo graficarlos.

Para quiénes decidan utilizar otra herramienta, `notebooks/dibu.pdf` tiene la misma
notebook ya compilada para que tomen esos ejemplos.

En `notebooks/svg_examples.ipynb` tienen ejemplos de SVG.