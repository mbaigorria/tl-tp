"""Archivo de setup del proyecto."""
from setuptools import setup

setup(
    name="dibu",
    version="0.0.1",
    author="Teoría de Lenguajes",
    packages=["dibu"],
    test_suite="tests"
)
